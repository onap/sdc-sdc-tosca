package org.onap.sdc.tosca.parser.impl;

import org.apache.commons.lang3.ArrayUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Helper structure used for resolving property value
 * when this property is located in the internal NodeTemplate
 * and the value is get_input
 */
public class PropertyValueContainer {
    /**
     * Property name
     */
    private String name;
    /**
     * Property value without get inputs,
     * null until get_input got resolved
     */
    private List<String> resolvedValue = new ArrayList<>();
    /**
     * get_input value if exists,
     * null if get_input either is not set as this property value,
     * or is resolved now
     */
    private List<String> getInputValue = new ArrayList<>();
    /**
     * Name of property a given get_input is used as a value,
     * null if get_input is not set or if the get_input was set
     * and it is the property the search is started from
     */
    private String inputFor;

    public PropertyValueContainer(String name, List<String> resolvedValue) {
        this.name = name;
        setResolvedValue(resolvedValue);
    }

    public PropertyValueContainer(String name, String inputFor, List<String> getInputValue) {
        this.name = name;
        this.inputFor = inputFor;
        setGetInputValue(getInputValue);
    }

    public void handleResolvedValue(List<String> resolvedValue) {
        setResolvedValue(resolvedValue);
        this.getInputValue.clear();
    }

    public void setResolvedValue(List<String> resolvedValue) {
        if (resolvedValue != null && !resolvedValue.isEmpty()) {
            this.resolvedValue.addAll(resolvedValue);
        }
    }

    public void setGetInputValue(List<String> getInputValue) {
        if (getInputValue != null && !getInputValue.isEmpty()) {
            this.getInputValue.addAll(getInputValue);
        }
    }

    public String getName() {
        return name;
    }

    public List<String> getResolvedValue() {
        return resolvedValue;
    }

    public List<String> getGetInputValue() {
        return getInputValue;
    }

    public String getInputFor() {
        return inputFor;
    }
}
