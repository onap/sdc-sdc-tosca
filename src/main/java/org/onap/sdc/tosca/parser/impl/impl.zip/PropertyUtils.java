package org.onap.sdc.tosca.parser.impl;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.ArrayUtils;
import org.onap.sdc.tosca.parser.enums.ComplexPropertyTypes;
import org.onap.sdc.tosca.parser.enums.SimplePropertyTypes;
import org.onap.sdc.toscaparser.api.NodeTemplate;
import org.onap.sdc.toscaparser.api.Property;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class PropertyUtils {

    private static Logger log = LoggerFactory.getLogger(PropertyUtils.class.getName());

    private static final String GET_INPUT = "get_input";

    private PropertyUtils() {}

    private static String calculatePropertyType(LinkedHashMap<String, Object> property) {
        String type = (String) property.get(SdcPropertyNames.PROPERTY_NAME_TYPE);
        if (isComplexPropertyType(type)) {
            //it might be a data type
            return getEntrySchemaType(property);
        }
        return type;
    }

    private static String calculatePropertyType(Property property) {
        String type = property.getType();
        if (isComplexPropertyType(type)) {
            //it might be a data type
            return (String)property.getEntrySchema().get(SdcPropertyNames.PROPERTY_NAME_TYPE);
        }
        return type;
    }

    private static boolean isSimplePropertyType(String type) {
        return Arrays.stream(SimplePropertyTypes.values()).anyMatch(v->v.getValue().equals(type));
    }

    private static boolean isComplexPropertyType(String type) {
        return Arrays.stream(ComplexPropertyTypes.values()).anyMatch(v->v.getValue().equals(type));
    }

    static boolean isDataPropertyType(String type) {
        return !isSimplePropertyType(type) && !isComplexPropertyType(type);
    }

    private static boolean isGetInput(Object value) {
        return value instanceof Map && ((LinkedHashMap)value).get(GET_INPUT) != null;
    }

    private static String getEntrySchemaType(LinkedHashMap<String, Object> property) {
        LinkedHashMap<String, Object> entrySchema = (LinkedHashMap<String, Object>)property.get(SdcPropertyNames.PROPERTY_NAME_ENTRY_SCHEMA);
        if (entrySchema != null) {
            return (String) entrySchema.get(SdcPropertyNames.PROPERTY_NAME_TYPE);
        }
        return null;
    }

    static Map<String, PropertyValueContainer> calculatePropertyValueAsPerTypeAndGetInput(NodeTemplate nodeTemplate, String[] path, Property property) {
        final String methodName = "calculatePropertyValueAsPerTypeAndGetInput";
        Map<String, PropertyValueContainer> propertyContainers = Maps.newHashMap();

        String propertyType = calculatePropertyType(property);

        if (path.length == 1) {
            propertyContainers = convertPropertyValue(nodeTemplate, propertyType, path);
        }
        else {
            propertyType = getInternalPropertyType(nodeTemplate, propertyType, path, 1);
            if (propertyType != null) {
                propertyContainers = convertPropertyValue(nodeTemplate, propertyType, path);
            }
        }
        if (log.isInfoEnabled() && propertyContainers.size() != 0) {
            List<String> valueList = propertyContainers.values()
                    .iterator()
                    .next()
                    .getResolvedValue();
            log.info("{} - found value for property {}: {}", methodName, path, valueList);
        }
        return propertyContainers;
    }

    static List<String> resolveGetInputsIfFound(NodeTemplate nodeTemplate, List<String> propertyValues) {
        List<String> valuesToRemove = new ArrayList<>();
        List<String> valuesToAdd = new ArrayList<>();
        for (String propertyValue : propertyValues) {
            int index = propertyValue.indexOf(GET_INPUT);
            if (index != -1) {
                String origValue = propertyValue.substring(index + GET_INPUT.length() + 1, propertyValue.length() - 1);
                valuesToRemove.add(propertyValue);
                String[] inputs = parseMultipleGetInputValue(origValue);
                //resolve each input andd add it to the property values response
                for (String input : inputs) {
                    valuesToAdd.addAll(convertPropertyValue(nodeTemplate, nodeTemplate.getPropertyType(input), new String[] {input}));
                }
            }
        }
        propertyValues.removeAll(valuesToRemove);
        propertyValues.addAll(valuesToAdd);
        return propertyValues;
    }

    private static String[] parseMultipleGetInputValue(String origValue) {
        if (origValue.startsWith("[")) {
            //the get_input keeps a list, we should split it
            return origValue.substring(1, origValue.length() - 1).split(", ");
        }
        return new String[] {origValue};
    }

    static Object processProperties(String[] split, LinkedHashMap<String, Property> properties) {
        Optional<Map.Entry<String, Property>> findFirst = properties.entrySet().stream().filter(x -> x.getKey().equals(split[0])).findFirst();
        if (findFirst.isPresent()) {
            Property property = findFirst.get().getValue();
            Object current = property.getValue();
            return iterateProcessPath(1, current, split);
        }
        String propName = (split != null && split.length > 0 ? split[0] : null);
        log.error("processProperties - property {} not found", propName);
        return null;
    }

    private static Object getPropertyValueFromTemplateByPath(NodeTemplate nodeTemplate, String[] path) {
        Object property = nodeTemplate.getPropertyValueFromTemplatesByName(path[0]);
        if (property != null) {
            if (path.length > 1) {
                return iterateProcessPath(1, property, path);
            }
            return property;
        }
        log.error("getPropertyValueFromTemplateByPath - property {} is not found", path[0]);
        return null;
    }


    @SuppressWarnings({ "unchecked", "rawtypes" })
    static Object iterateProcessPath(Integer index, Object current, String[] split) {
        if (current == null) {
            log.error("iterateProcessPath - this input has no default");
            return null;
        }
        if (split.length > index) {
            for (int i = index; i < split.length; i++) {
                if (current instanceof Map) {
                    current = ((Map<String, Object>) current).get(split[i]);
                } else if (current instanceof List) {
                    current = ((List) current).get(0);
                    i--;
                }
                else {
                    log.error("iterateProcessPath - found an unexpected leaf where expected to find a complex type");
                    return null;
                }
            }
        }
        if (current != null) {
            return current;
        }
        log.error("iterateProcessPath - Path not Found");
        return null;
    }

    private static Map<String, PropertyValueContainer> convertPropertyValue(NodeTemplate nodeTemplate, String propertyType, String[] path) {
        return convertPropertyValue(nodeTemplate, propertyType, path, "");
    }

    private static Map<String, PropertyValueContainer> convertPropertyValue(NodeTemplate nodeTemplate, String propertyType, String[] path, String inputFor) {
        final String methodName = "convertPropertyValue";
        final String propertyName = path[path.length - 1];
        Map<String, PropertyValueContainer> propertyContainers = Maps.newHashMap();

        if (isDataPropertyType(propertyType)) {
            log.error("{} - property type {} is data type, reject this request", methodName, propertyType);
            return propertyContainers;
        }

        Object value = getPropertyValueFromTemplateByPath(nodeTemplate, path);

        if (value == null) {
            log.warn("{} - value of requested property [{}] is not found", methodName, propertyName);
            return propertyContainers;
        }

        PropertyValueContainer container = buildPropertValueByType(propertyName, inputFor, value, propertyType);
        if (container != null) {
            propertyContainers.put(propertyName, container);
        }
        return propertyContainers;
    }

    private static PropertyValueContainer buildPropertValueByType(String propertyName, String inputFor, Object value, String type) {
        final String methodName = "buildPropertValueByType";

        if (isGetInput(value)) {
            log.info("{} - type of requested property [{}] is get_input", methodName, propertyName);
            return new PropertyValueContainer(propertyName, inputFor, Collections.singletonList(String.valueOf(value)));
        }
        if (isSimplePropertyType(type)) {
            log.info("{} - type of requested property [{}] is simple or it is get_input", methodName, propertyName);
            return new PropertyValueContainer(propertyName, Collections.singletonList(String.valueOf(value)));

        }
        //assuming that list/map of data types had been detected and rejected before,
        //we can have only list/map of simple types on this stage
        if (type.equals(ComplexPropertyTypes.LIST.getValue())) {
            log.info("{} - type of requested property [{}] is list", methodName, propertyName);
            return new PropertyValueContainer(propertyName, ((((ArrayList<Object>) value)
                    .stream()
                    .map(String::valueOf)
                    .collect(Collectors.toList()))));
        }
        if (type.equals(ComplexPropertyTypes.MAP.getValue())) {
            log.info("{} - type of requested property [{}] is map", methodName, propertyName);
            return new PropertyValueContainer(propertyName, (((Map<String, Object>) value)
                    .values()
                    .stream()
                    .map(String::valueOf)
                    .collect(Collectors.toList())));
        }
        log.error("{} - type of requested property [{}] is incorrect, the property value can't be retrieved, the request will be rejected",
                    methodName, propertyName);
        return null;
    }

    //todo complexProperty should be nodeTemplate.getCustomDef().get(complexPropName), index = 1 -?
    @VisibleForTesting
    private static String getInternalPropertyType(NodeTemplate nodeTemplate, String dataTypeName, String[] path, int index) {
        final String methodName = "getInternalPropertyType";
        if (path.length > index) {
            LinkedHashMap<String, Object> complexProperty = (LinkedHashMap<String, Object>) nodeTemplate.getCustomDef().get(dataTypeName);
            if (complexProperty != null) {
                LinkedHashMap<String, Object> properties = (LinkedHashMap<String, Object>) complexProperty.get(SdcPropertyNames.PROPERTY_NAME_PROPERTIES);
                if (properties != null) {
                    LinkedHashMap<String, Object> foundProperty = (LinkedHashMap<String, Object>) (properties).get(path[index]);
                    if (foundProperty != null) {
                        String propertyType = calculatePropertyType(foundProperty);
                        log.info("{} - type {} is data type", methodName, propertyType);
                        if ((index == path.length - 1)){
                            log.info("{} - the last element {} in the property path is found", methodName, path[index]);
                            return propertyType;
                        }
                        return getInternalPropertyType(nodeTemplate, propertyType, path, index + 1);
                    }
                    else {
                        log.error("{} - the property [{}] is not found", methodName, path[index]);
                    }
                }
            }
        }
        //stop searching - seems as wrong flow: the path is finished but the value is not found yet
        log.error("{} - the property path {} is incorrect, the request will be rejected", methodName, path);
        return null;
    }

    private static String getValueWithoutGetInputPrefix(String value) {
        int index = value.indexOf(GET_INPUT);
        if (index != -1) {
            return value.substring(index + GET_INPUT.length() + 1, value.length() - 1);
        }
        return value;
    }

    /*private static boolean isSimplePropertyFound(NodeTemplate nodeTemplate, String[] path, int index, String methodName, LinkedHashMap<String, Object> foundProperty) {
        //property exists, check its type
        String propertyType = PropertyUtils.calculatePropertyType(foundProperty);
        log.info("{} - type {} is data type", methodName, propertyType);
        if (PropertyUtils.isSimplePropertyType(propertyType)) {
            //it is simple type - we can stop searching
            log.info("{} - the property path {} search is finished", methodName, path);
            if (index == path.length - 1) {
                log.info("{} - property path {} is correct", methodName, path);
                return true;
            }
            return false;
        }
        return isPropertyPathValid(nodeTemplate, propertyType, path, index + 1);
    }*/


}
