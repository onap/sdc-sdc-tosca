package org.onap.sdc.tosca.parser.enums;

public enum JToscaValidationIssueType {
	CRITICAL,
	WARNING
}
